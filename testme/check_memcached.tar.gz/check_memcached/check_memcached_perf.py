#!/bin/env python
#encoding: utf8
#

import getpass
import sys
import telnetlib


class check_mc_perf:
	'''
		check memcached performance.
 	'''
	def __init__(self, host="localhost", port=11211):
		self.chost = host
		slef.cport = port

	def get_mc_stats(self):
		tn = telnetlib.Telnet(self.chost, self.cport)
		tn.write("stats\n")
		tn.write("quit\n")
		return tn.read_all();
				
	def worker(self):
		'''
		check memcached performance.
		'''
		res = get_mc_stats()		
		


HOST = "192.168.98.91"
PORT = 11211
#user = raw_input("Enter your remote account: ")
#password = getpass.getpass()

tn = telnetlib.Telnet(HOST, PORT)

'''
tn.read_until("login: ")
tn.write(user + "\n")
if password:
    tn.read_until("Password: ")
    tn.write(password + "\n")
'''

tn.write("stats\n")
tn.write("quit\n")

print tn.read_all()

