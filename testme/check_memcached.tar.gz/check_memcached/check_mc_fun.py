#!/bin/env python
# encoding: utf8
# check memcached function
#

import sys
import memcache
import time


def main():
	fp = None

	try: 
		mc = memcache.Client(['192.168.98.91:11211'], debug=1)
		
		fp = open("data", "r")
		value = fp.readlines()
		print len(value)
		#print value
		
		v=mc.set("key1",value,0,1024) 
		#v=mc.set("key1",value) 
		print v
		#mc.set("key2","hello world") 

		v=mc.get("key1")
		#v2=mc.get("key2") 

		print len(v)
		#print v2
		#print len(v)
		time.sleep(10)
	except Exception, ex:
		print "error: %s" % ex
	
	finally:
		if fp: fp.close()

#main
if __name__ == '__main__':
	main()
